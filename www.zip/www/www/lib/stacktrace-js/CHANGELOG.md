## v0.6.2

* Ignore test/ dir in bower
* Migrate references eriwen/javascript-stacktrace -> stacktracejs/stacktrace.js

## v0.6.1

* Fix printStackTrace throws exception with "use strict" code and PhantomJS

## v0.6.0

* Added AMD support using a UMD pattern (thanks @jeffrose)

## v0.5.3

* Fix Chrome 27 detection; Chrome no longer has Error#arguments

## v0.5.1

* Fix Bower integration; Added proper bower.json file

## v0.5.0

* Lots and lots of stuff

